﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class contact : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
        if (txtEmail.Text != "" && !string.IsNullOrEmpty(txtname.Text) && !string.IsNullOrEmpty(txtPhone.Text) && !string.IsNullOrEmpty(txtSubject.Text) && !string.IsNullOrEmpty(txtMessage.Text))
        {
            SendEmail();
        }
       
    }
    private void SendEmail()
    {
        try
        {

            //MailMessage message = new MailMessage();
            //message.From = new MailAddress("sales@mypulsario.com");
            //message.To.Add(new MailAddress("ravinderkumar@cogniter.com"));

            //message.Body = string.IsNullOrEmpty(txtMessage.Text) ? "" : txtMessage.Text;
            //message.Subject = "User want to contact us.";


            //SmtpClient client = new SmtpClient("smtp.gmail.com", 587);

            ////if using gmail smtp settings(dev system uses gmail):
            //if ("smtp.gmail.com".Contains("gmail"))
            //{
            //    client.EnableSsl = true;
            //    client.Credentials = new NetworkCredential("hfdefender.vinformatix@gmail.com", "Rcopia01");
            //}

            //client.Send(message);

            StringBuilder str = new StringBuilder();

            MailMessage ObjMailMessage = new MailMessage();

            ObjMailMessage.From = new MailAddress("sales@mypulsario.com");
            ObjMailMessage.To.Add(new MailAddress("sales@mypulsario.com"));
            ObjMailMessage.Subject = txtSubject.Text;
            ObjMailMessage.IsBodyHtml = true;
            str.Append("<!DOCTYPE html PUBLIC ' -//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>");
            str.Append("<html xmlns='http://www.w3.org/1999/xhtml'><head>");
            str.Append("<meta http-equiv='Content - Type' content='text/html; charset=UTF-8'>");
            str.Append("<title>Pulsario</title></head>");
            str.Append("<body style='padding:0px; margin:0px;'>");
            str.Append("<table width='700' cellpadding='0' cellspacing='0' style='padding:0px; border:1px solid #ccc;  font-family:arial;' align='center'><tr>");
            str.Append("<td style='text-align:center; padding:15px 15px 15px 15px; background:#0e1030;' colspan='2'><img src='http://pulsario.com/images/Pulsario-Logo-2color-secondary_white-blue.png' style='margin:0px; padding:0px; max-width:200px;'/></td></tr>");
            str.Append("<td style='font-size: 14px; padding: 15px 15px 15px 15px; color: #5c5c5c;' colspan='2'><strong>Name:</strong> "+txtname.Text+"<br/>");
            str.Append("<strong>Phone:</strong> "+txtPhone.Text+"<br/>");
            str.Append("<strong>Email:</strong> "+txtEmail.Text+"<br/><br/>");
            str.Append("<strong>Subject:</strong> "+txtSubject.Text+"<br/><br/>");
            str.Append("</td></tr><tr>");
            str.Append("<td colspan='2' style='font-size: 14px; padding: 5px 15px 15px 15px; color: #5c5c5c; line-height: 22px;'><strong>Message:</strong><br/>" + txtMessage.Text);
            str.Append("</td></tr><tr>");
            str.Append("<td colspan='2' style='font-size: 14px; padding: 50px 15px 15px 15px; color: #5c5c5c; line-height: 22px;'>Regards,<br/>");
            str.Append("The Pulsario.com Team</tr>");
            str.Append("</table></body></html>");
            ObjMailMessage.Body = str.ToString();
            SmtpClient emailClient = new SmtpClient("webmail.pulsario.com");
            emailClient.Port = 26;
            System.Net.NetworkCredential smtpUserInfo = new System.Net.NetworkCredential("smtp@pulsario.com", "wdqA09!2");
            emailClient.UseDefaultCredentials = false;
            emailClient.Credentials = smtpUserInfo;
            emailClient.Send(ObjMailMessage);
            txtname.Text = "";
            txtPhone.Text = "";
            txtSubject.Text = "";
            txtMessage.Text = "";
            txtLitrValidation.Text = "Get In Touch. Thanks for contacting us! We will get in touch with you shortly.";
            panel1.Visible = false;
            ObjMailMessage = null;


        }
        catch (Exception ex)
        {
            txtLitrValidation.Text = ex.Message;
        }
    }
}